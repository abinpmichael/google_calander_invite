<!DOCTYPE html><html>
<head>
    <title>GOOGLE CALENDAR - insert, change and delete Google Calenda event</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <style>
        body{
            margin: 0;
            width: 100%;
            font-family: Verdana, Arial;
        }
        #centro{
            width: 780px;
            margin: auto;
        }
        .calendario{
            position: relative;
            width: 800px;
            height: 600px;
            margin-left:-390px;
            left: 50%;
            float: left;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
        }
        #datahora{
            width: 250px;
            float: left;
        }
        #cento{
            width: 780px;
            float: left;
        }
        #centro .primo{
            width: 100%;
            background-color: #E3E9FF;
            padding: 10px;
            margin: 50px 0;
            float: left;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
        }
        label {
            width: 780px;
            margin: 5px 5px 0;
            float: left;
            padding-top: 10px;
        }

        input{
            margin: 5px;
            float: left;
            padding: 5px 10px;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            border: 1px #CCC solid;
        }
        input[type="text"]{
            width: 750px;
        }
        input[type="date"]{
            width: 125px;
        }
        input[type="time"]{
            width: 70px;
        }
        input[type="submit"]{

        }

        input:focus{
            border: 1px  #cc0000 solid;
            box-shadow: 0 0 5px #cc0000;
        }
        .btn {
            background: #3498db;
            background-image: -webkit-linear-gradient(top, #3498db, #2980b9);
            background-image: -moz-linear-gradient(top, #3498db, #2980b9);
            background-image: -ms-linear-gradient(top, #3498db, #2980b9);
            background-image: -o-linear-gradient(top, #3498db, #2980b9);
            background-image: linear-gradient(to bottom, #3498db, #2980b9);
            -webkit-border-radius: 5;
            -moz-border-radius: 5;
            border-radius: 5px;
            font-family: Arial;
            color: #ffffff;
            font-size: 20px;
            padding: 10px 20px 10px 20px;
            text-decoration: none;
            cursor: pointer;
        }

        .btn:hover {
            background: #3cb0fd;
            background-image: -webkit-linear-gradient(top, #3cb0fd, #3498db);
            background-image: -moz-linear-gradient(top, #3cb0fd, #3498db);
            background-image: -ms-linear-gradient(top, #3cb0fd, #3498db);
            background-image: -o-linear-gradient(top, #3cb0fd, #3498db);
            background-image: linear-gradient(to bottom, #3cb0fd, #3498db);
            text-decoration: none;
        }

    </style>
</head>
<body>

    <?php
    session_start();
    require __DIR__ . '/vendor/autoload.php';
    /*require 'google-api-php-client-master/src/Google/autoload.php';
    require_once 'google-api-php-client-master/src/Google/Client.php';
    require_once 'google-api-php-client-master/src/Google/Service/Calendar.php';*/

    /*$client_id = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'; //change this
    $Email_address = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'; //change this
    $key_file_location = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'; //change this*/
function getClient()
{
   $client = new Google_Client();

    $client->setApplicationName('Calendar API Test');

    $client->setScopes( ['https://www.googleapis.com/auth/calendar'] );
    // $client->setScopes(Google_Service_Calendar::CALENDAR_READONLY);

    $client->setAuthConfig('credentials.json');
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');

    // Load previously authorized token from a file, if it exists.
    // and refresh tokens, and is created automatically when the authorization flow completes for the first time.
    $tokenPath = 'token.json';
    if (file_exists($tokenPath)) {
        $accessToken = json_decode(file_get_contents($tokenPath), true);
        $client->setAccessToken($accessToken);
    }

    // If there is no previous token or it's expired.
    if ($client->isAccessTokenExpired()) {
        // Refresh the token if possible, else fetch a new one.
        if ($client->getRefreshToken()) {
            $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
        } else {
            // Request authorization from the user.
            $authUrl = $client->createAuthUrl();
            printf("Open the following link in your browser:\n%s\n", $authUrl);
            print 'Enter verification code: ';

            // Check Param on redirected URL, for ?code=#############  
            // you have to copy only ?code= $_GET parms data and paste in console
            $authCode = trim(fgets(STDIN)); // Get code after Authentication

            // Exchange authorization code for an access token.
            $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
            $client->setAccessToken($accessToken);

            // Check to see if there was an error.
            if (array_key_exists('error', $accessToken)) {
                throw new Exception(join(', ', $accessToken));
            }
        }

        // Save the token to a file.
        if (!file_exists(dirname($tokenPath))) {
            mkdir(dirname($tokenPath), 0700, true);
        }

        file_put_contents($tokenPath, json_encode($client->getAccessToken()));
    }
    return $client;
}


    if ($_POST) {

        $Summary = $_POST['Summary'];
        $Location = $_POST['Location'];
        $DateStart = $_POST['DateStart'];
        $TimeStart = $_POST['TimeStart'];
        $DateEnd = $_POST['DateEnd'];
        $TimeEnd = $_POST['TimeEnd'];
        $status = $_POST['status'];



        if ($status == 'Insert') {
            $client = getClient();
            $service = new Google_Service_Calendar($client);
            //--------------- trying to insert EVENT --------------- 
            $event = new Google_Service_Calendar_Event();
            $event->setSummary($Summary);
            $event->setLocation($Location);
            $start = new Google_Service_Calendar_EventDateTime();
            $datatimeI = geratime(DataIT2DB($DateStart), $TimeStart);
print_r($datatimeI);
            $start->setDateTime($datatimeI);
            $event->setStart($start);
            $end = new Google_Service_Calendar_EventDateTime();
            $datatimeF = geratime(DataIT2DB($DateEnd), $TimeEnd);

            $end->setDateTime($datatimeF);
            $event->setEnd($end);
            $attendee1 = new Google_Service_Calendar_EventAttendee();
            $attendee1->setEmail('abinpmichaels@gmail.com');
            $attendees = array($attendee1);
            $event->attendees = $attendees;
            $createdEvent = $service->events->insert('primary', $event);
            $_SESSION['eventID'] = $createdEvent->getId();
        } else if ($status == 'Cancel') {
            //--------------- trying to del EVENT --------------- 
            $createdEvent = $service->events->delete('primary', $_SESSION['eventID']);
        } else if ($status == 'Update') {
            //--------------- trying to update EVENT --------------- 
             $client = getClient();
            $service = new Google_Service_Calendar($client);
            $rule = $service->events->get('primary', $_SESSION['eventID']);


            $event = new Google_Service_Calendar_Event();
            $event->setSummary($Summary);
            $event->setLocation($Location);
            $start = new Google_Service_Calendar_EventDateTime();
            $datatimeI = geratime(DataIT2DB($DateStart), $TimeStart);

            $start->setDateTime($datatimeI);
            $event->setStart($start);
            $end = new Google_Service_Calendar_EventDateTime();
            $datatimeF = geratime(DataIT2DB($DateEnd), $TimeEnd);

            $end->setDateTime($datatimeF);
            $event->setEnd($end);
            $attendee1 = new Google_Service_Calendar_EventAttendee();
            $attendee1->setEmail('xxxxxxxxxx@gmail.com'); //change this
            $attendees = array($attendee1);
            $event->attendees = $attendees;

            $updatedRule = $service->events->update('primary', $rule->getId(), $event);
        }
    }

    function DataIT2DB($datapega) {
        if ($datapega) {
            $data = explode('/', $datapega);
            if (count($data) > 1) {
                $datacerta = $data[2] . '-' . $data[1] . '-' . $data[0];
            } else {
                $datacerta = $datapega;
            }
        } else {
            $datacerta = $datapega;
        }
        return $datacerta;
    }

    function geratime($DateStart, $TimeStart) {
        $dataHora = $DateStart . 'T' . $TimeStart . ':00.000+02:00'; //Fuso Rome
        return $dataHora;
    }
    ?>

    <div id="contenut" style="width: 100%; float: left;">
        <div id="centro">
            <div class="primo">
                <form name="adicionar" method="POST" action="#">
                    ID evento: <?php echo ( isset($_SESSION['eventID']) ? $_SESSION['eventID'] : "" ); ?>
                    <input type="hidden" name="" value="<?php echo ( isset($_SESSION['eventID']) ? $_SESSION['eventID'] : "" ); ?>" />
                    <input type="text" name="Summary" value="<?php echo ( isset($_POST['Summary']) ? $_POST['Summary'] : "" ); ?>" placeholder="Title"/>
                    <input type="text" name="Location" value="<?php echo ( isset($_POST['Location']) ? $_POST['Location'] : "" ); ?>" placeholder="Location "/>
                    <div id="datahora">
                        <label>Starting Date</label>
                        <input type="date" name="DateStart" value="<?php echo ( isset($_POST['DateStart']) ? $_POST['DateStart'] : "" ); ?>" placeholder="DD/MM/YYYY"/>
                        <input type="time" name="TimeStart" value="<?php echo ( isset($_POST['TimeStart']) ? $_POST['TimeStart'] : "" ); ?>" placeholder="10:20"/>
                    </div>
                    <div id="datahora">
                        <label>Ending Date</label>
                        <input type="date" name="DateEnd" value="<?php echo ( isset($_POST['DateEnd']) ? $_POST['DateEnd'] : "" ); ?>" placeholder="DD/MM/YYYY"/>
                        <input type="time" name="TimeEnd" value="<?php echo ( isset($_POST['TimeEnd']) ? $_POST['TimeEnd'] : "" ); ?>" placeholder="10:20" />
                    </div>
                    <div id="cento">
                        <input class="btn" type="submit" value="Insert" name="status" />
                        <input class="btn" type="submit" value="Cancel" name="status" />
                        <input class="btn" type="submit" value="Update" name="status" />
                    </div>

                </form>
            </div>
        </div>
    </div>
</body>